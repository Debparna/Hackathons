*With 4 hours for this challenge here is everything I could come up with - 
* I implemented react to create servers in index.html
* As an alternative, given the time, I also implemented a html frontend in mesos.html using bootstrap
*With some more time I wouldve implemented the server to run using the add server button that would run on the canvas. So instead I split it up into two versions,

    - one using javascript onclick to set up an http server, but I realized that this would open in a different page so and I would not be able to instantiate two servers so I moved on to my other version using react.
    - the other one was using react as page components
* Given more time, I would use the react components on my html interface so along with functionality it would have a nice interface.

I used bootstrap, react, html, css and sass. 


*********
I found this challenge very interesting, thankyou for giving me a chance to complete it. 

