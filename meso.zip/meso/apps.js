const apps = [
  {
    name: "Hadoop",
    abbreviation: "Hd",
    color: "#FF00CC"
  },
  {
    name: "Rails",
    abbreviation: "Ra",
    color: "#0D00FF"
  },
  {
    name: "Chronos",
    abbreviation: "Ch",
    color: "#00B3FF"
  },
  {
    name: "Storm",
    abbreviation: "St",
    color: "#00FFB7"
  },
  {
    name: "Spark",
    abbreviation: "Sp",
    color: "#91FF00"
  }
];

export default appTypes;
