import React, { Comp } from 'react';
import appTypes from '../App.js';

export default class AvailableAppList extends Component {
  render() {
    const listElems = App.map(type => {
      const style = {
        borderLeft: "2px solid "+ type.color
      }

      const plusStyle = {
        backgroundColor: type.color
      }

      return <li style={style} key={type.name}>
                {type.name}

                <div className="circle minus">
                  <span>-</span>
                </div>

                <div style={plusStyle} className="circle plus">
                  <span>+</span>
                </div>

              </li>;
    });

    return (
      <article className="app-list">
        <p>Available Apps</p>
        <ul className="list">
          {listElems}
        </ul>
      </article>
    );
  }
}
