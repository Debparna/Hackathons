import React, { Component } from 'react';

export default class Canvas extends Component {
  propTypes: {
    servers: React.PropTypes.array.isRequired
  }

  render() {
    let serverBlocks = [];
    for (let i = 0; i < this.props.servers.length; i++) {
      serverBlocks.push(<div key={i} className="server-block"></div>);
    }

    return (
      <div className="canvas">
        <h1>Server Canvas</h1>
        <div className="blocks">
          {Blocks}
        </div>
      </div>
    );
  }
}
