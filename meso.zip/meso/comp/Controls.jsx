import React, { Component } from 'react';

export default class Controls extends Component {
  propTypes: {
    add: React.PropTypes.func,
    destroy: React.PropTypes.func
  }

  render() {
    return (
      <div className="controls">
        <div className="add" onClick={this.props.add}>
          <span className="pe-5s-plus pe-3x"></span>
          <p>Add Server</p>
        </div>
        <div className="destroy" onClick={this.props.destroy}>
          <span className="pe-5s-trash pe-3x"></span>
          <p>Destroy</p>
        </div>
      </div>
    );
  }
}
