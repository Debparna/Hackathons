import React, { Component } from 'react';
import Controls from './Controls.jsx';
import ServerCanvas from './ServerCanvas.jsx';
import App from './App.jsx';


export default class sim extends Component {
  constructor(props) {
    super(props);
    this.state = {
      servers: [
        {
          apps: []
        },
        {
          apps: []
        },
        {
          apps: []
        },
        {
          apps: []
        }
      ]
    };
  }

  destroyServer() {
    if (this.state.servers.length) {
      this.setState({
        servers: this.state.servers.slice(0, this.state.servers.length-1)
      });
    }
  }

  addServer() {
    this.setState({
      servers: this.state.servers.concat({})
    });
  }

  render() {
    return (
      <div className="sim">
        <section className="sidebar">
          <Controls
            add={this.addServer.bind(this)}
            destroy={this.destroyServer.bind(this)}
          />

          <App />
        </section>
        <main>
          <ServerCanvas servers={this.state.servers} />
        </main>
      </div>
    );
  }
}
