import React from 'react';
import ReactDOM from 'react-dom';
import MesosSimulator from './components/MesosSimulator.jsx';
require('./stylesheets/main.scss');
ReactDOM.render( < MesosSimulator / > , document.getElementById('app'));